import React from "react";
import FeedPlan from "./components/FeedPlan";

function App() {
  return (
    <div className="p-4">
      <FeedPlan />
    </div>
  );
}

export default App;
